import { SplittingText } from "@/components/animate-ui/primitives/texts/splitting";
import AboutImage from "@/assets/images/about-me.svg";

const AboutStory = () => {
  return (
    <section className="relative mx-auto max-w-7xl px-6 py-24 overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
        {/* Image */}
        <div className="flex justify-center md:justify-start order-2 md:order-1">
          <img
            src={AboutImage}
            alt="Marco Talaat"
            className="w-full max-w-md rounded-2xl object-cover"
          />
        </div>

        {/* Copy */}
        <div className="space-y-6 text-center md:text-left order-1 md:order-2">
          <span className="text-primary uppercase tracking-[4px] text-sm font-medium">
            My Story
          </span>

          <h2 className="text-4xl md:text-5xl font-bold text-neutral-900">
            <SplittingText text="From Curiosity to Code" aria-hidden="true" />
          </h2>

          <div className="space-y-4 text-neutral-700 text-lg leading-relaxed max-w-xl mx-auto md:mx-0">
            <p>
              I started out customizing WordPress themes for small local
              businesses, and quickly got curious about what was happening
              under the hood. That curiosity turned into a deep dive into PHP,
              then into building custom plugins, dashboards, and workflows
              that off-the-shelf themes simply couldn't do.
            </p>

            <p>
              Today I split my time between WordPress ecosystems and modern
              stacks like React and Laravel — bridging the gap between
              flexible content management and fully custom, scalable
              applications. Whether it's an AJAX-powered filtering system or a
              multilingual client portal, I care most about building things
              that hold up as they grow.
            </p>

            <p>
              Outside of client work, I'm usually refining a personal
              dashboard project or picking apart a new framework just to see
              how it thinks.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutStory;
