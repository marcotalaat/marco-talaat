import { SplittingText } from "@/components/animate-ui/primitives/texts/splitting";

import {
  FaPhp,
  FaWordpress,
  FaReact,
  FaLaravel,
  FaElementor,
  FaHtml5,
  FaCss3Alt,
  FaJs,
} from "react-icons/fa";

import { SiTailwindcss, SiMysql, SiWoocommerce } from "react-icons/si";

const skillGroups = [
  {
    title: "Backend & CMS",
    description: "Where the logic and content structure live.",
    skills: [
      { icon: <FaPhp />, name: "PHP" },
      { icon: <FaWordpress />, name: "WordPress" },
      { icon: <FaLaravel />, name: "Laravel" },
      { icon: <SiWoocommerce />, name: "WooCommerce" },
    ],
  },
  {
    title: "Frontend",
    description: "Where users actually feel the work.",
    skills: [
      { icon: <FaReact />, name: "React" },
      { icon: <FaJs />, name: "JavaScript" },
      { icon: <SiTailwindcss />, name: "Tailwind" },
      { icon: <FaHtml5 />, name: "HTML5" },
      { icon: <FaCss3Alt />, name: "CSS3" },
    ],
  },
  {
    title: "Tools & Data",
    description: "What holds everything together.",
    skills: [
      { icon: <FaElementor />, name: "Elementor" },
      { icon: <SiMysql />, name: "MySQL" },
    ],
  },
];

const AboutSkills = () => {
  return (
    <section className="relative mx-auto max-w-7xl px-6 py-24">
      <div className="text-center mb-16">
        <span className="text-primary uppercase tracking-[4px] text-sm font-medium">
          What I Work With
        </span>

        <h2 className="text-4xl md:text-5xl font-bold mt-4 text-neutral-900">
          <SplittingText text="Skills & Tools" aria-hidden="true" />
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {skillGroups.map((group, idx) => (
          <div
            key={idx}
            className="
              rounded-[30px]
              p-8
              border border-neutral-200
              bg-white/60
              backdrop-blur-sm
              transition-all duration-500
              hover:-translate-y-2
              hover:border-primary/40
            "
          >
            <h3 className="text-2xl font-bold text-neutral-900 mb-2">
              {group.title}
            </h3>

            <p className="text-neutral-600 mb-6">{group.description}</p>

            <div className="flex flex-wrap gap-3">
              {group.skills.map((skill, sIdx) => (
                <div
                  key={sIdx}
                  className="
                    flex items-center gap-2
                    px-4 py-2
                    rounded-xl
                    bg-neutral-900/5
                    border border-neutral-200
                    text-neutral-800
                    transition-all duration-300
                    hover:bg-primary hover:text-white hover:border-primary
                  "
                >
                  <span className="text-lg text-primary [&:hover]:text-white">
                    {skill.icon}
                  </span>
                  <span className="text-sm font-medium">{skill.name}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default AboutSkills;
