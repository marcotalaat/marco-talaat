import { SplittingText } from "@/components/animate-ui/primitives/texts/splitting";
import { TypingText } from "@/components/animate-ui/primitives/texts/typing";

import {
  FaPhp,
  FaWordpress,
  FaReact,
  FaLaravel,
  FaElementor,
  FaHtml5,
  FaCss3Alt,
  FaJs,
} from "react-icons/fa";

import { SiTailwindcss, SiMysql, SiWoocommerce } from "react-icons/si";

// Same skill set as the Home hero — keep both in sync, or lift this
// array into a shared /data/skills.js if it starts to drift.
const skills = [
  { icon: <FaPhp />, name: "PHP" },
  { icon: <FaWordpress />, name: "WordPress" },
  { icon: <FaReact />, name: "React" },
  { icon: <FaLaravel />, name: "Laravel" },
  { icon: <FaElementor />, name: "Elementor" },
  { icon: <SiWoocommerce />, name: "WooCommerce" },
  { icon: <FaJs />, name: "JavaScript" },
  { icon: <SiTailwindcss />, name: "Tailwind" },
  { icon: <SiMysql />, name: "MySQL" },
  { icon: <FaHtml5 />, name: "HTML5" },
  { icon: <FaCss3Alt />, name: "CSS3" },
];

const AboutHero = () => {
  return (
    <section className="relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 py-32 flex flex-col items-center justify-center text-center space-y-8">
        <SplittingText
          text="About Me"
          aria-hidden="true"
          className="text-xl font-medium text-neutral-600"
        />

        <h1 className="text-6xl md:text-7xl font-extrabold text-neutral-900">
          <SplittingText text="Marco Talaat" aria-hidden="true" />
        </h1>

        <TypingText
          text="Turning ideas into structured, scalable digital systems"
          className="text-2xl md:text-3xl font-semibold text-primary"
        />

        <p className="max-w-3xl text-neutral-700 text-lg md:text-xl leading-relaxed">
          I'm a PHP &amp; WordPress developer who builds beyond the template —
          custom dashboards, dynamic content systems, and user-based
          platforms. Here's a closer look at how I work, what I've built, and
          where I'm headed next.
        </p>
      </div>

      <div className="relative py-8 my-10 border-y border-neutral-200 overflow-hidden">
        <div className="marquee flex gap-12 items-center">
          {[...skills, ...skills].map((skill, index) => (
            <div
              key={index}
              className="flex items-center gap-3 text-neutral-700 shrink-0"
            >
              <span className="text-3xl text-primary">{skill.icon}</span>

              <span className="text-lg font-medium whitespace-nowrap">
                {skill.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutHero;
