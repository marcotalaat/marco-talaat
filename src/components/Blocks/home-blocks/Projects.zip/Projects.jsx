import React from "react";
import { SplittingText } from "@/components/animate-ui/primitives/texts/splitting";
import { ArrowUpRight, Globe, BriefcaseBusiness } from "lucide-react";
import TusLogo from "../../../assets/images/Company Logo/TUs.png";
import ilampLogo from "../../../assets/images/Company Logo/ilamp.svg";
import personalLogo from "../../../assets/images/marco-logo-colored-2.png";
import projects from "@/data/projects";

const companyLogos = {
  TUs: TusLogo,
  iLamp: ilampLogo,
  personal: personalLogo,
};

const HomeProjects = () => {
  return (
    <section className="relative py-32 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-7xl font-black mb-6">
            <SplittingText text="My Works" aria-hidden="true" />
          </h2>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-10">
          {projects.map((project, idx) => (
            <a
              key={idx}
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              className="
                group relative block overflow-hidden
                rounded-[30px]
                border border-white/10
                bg-[#0F172A]
                transition-all duration-500
                hover:-translate-y-3
                hover:rotate-0
                hover:scale-[1.01]
              "
            >
              {/* Browser Top Bar */}
              <div
                className="
                  absolute top-0 left-0 right-0 z-20
                  h-12 px-5
                  flex items-center gap-2
                  bg-black/50 backdrop-blur-md
                  border-b border-white/10
                  overflow-hidden
                "
              >
                <span className="w-3 h-3 rounded-full bg-red-400" />
                <span className="w-3 h-3 rounded-full bg-yellow-400" />
                <span className="w-3 h-3 rounded-full bg-green-400" />

                <div
                  className="
                    ml-3 flex items-center gap-2
                    text-xs text-gray-400
                    truncate
                  "
                >
                  <Globe size={14} />
                  {project.liveUrl.replace("https://", "")}
                </div>
              </div>

              {/* Screenshot */}
              <div className="relative h-[400px] overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="
                    w-full h-full object-cover object-top
                    transition-transform duration-[7000ms]
                    ease-linear
                    group-hover:translate-y-[-45%]
                  "
                />

                {/* Overlay */}
                <div
                  className="
                    absolute inset-0
                    bg-gradient-to-t
                    from-black/80
                    via-black/10
                    to-transparent
                  "
                />
              </div>

              {/* Bottom Bar */}
              <div
                className="
                  absolute bottom-0 left-0 right-0 z-20
                  backdrop-blur-xl
                  bg-black/50
                  border-t border-white/10
                  px-6 py-5
                "
              >
                <div className="flex items-center justify-between gap-4">
                  {/* Left */}
                  <div className="flex items-center gap-4 min-w-0">
                    {/* Logo */}
                    <div
                      className="
                        w-14 h-14 rounded-2xl
                        bg-white
                        p-3 shrink-0
                        shadow-lg
                      "
                    >
                      <img
                        src={companyLogos[project.powered]}
                        alt={project.powered}
                        className="w-full h-full object-contain"
                      />
                    </div>

                    {/* Text */}
                    <div className="min-w-0">
                      <h3
                        className="
                          text-white text-xl font-semibold
                          truncate
                        "
                      >
                        {project.title}
                      </h3>

                      <p className="text-sm text-gray-400">
                        {project.category} • {project.powered}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Glow */}
              <div
                className="
                  absolute inset-0 opacity-0
                  group-hover:opacity-100
                  transition duration-500
                  bg-gradient-to-br
                  from-primary/10
                  via-transparent
                  to-white/5
                  pointer-events-none
                "
              />
            </a>
          ))}
        </div>

        {/* Button */}
        <div className="flex justify-center mt-20">
          <button
            className="
                group relative overflow-hidden
                px-10 py-5 rounded-2xl
                bg-black
                text-white
                border border-white/10
                text-lg font-medium
                transition-all duration-300
                hover:bg-primary
                hover:text-white
                hover:border-primary
                hover:scale-105
                shadow-lg shadow-black/20
            "
          >
            <span className="relative z-10 flex items-center gap-3">
              Check More Projects
              <ArrowUpRight
                size={20}
                className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
              />
            </span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default HomeProjects;
